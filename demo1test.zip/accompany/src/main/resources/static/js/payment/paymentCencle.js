$(function () {
    alert('결제가 취소되었습니다.');
    window.self.close()
});