$(function () {
    alert('결제실패, 확인 후 다시 시도하세요.');
    window.self.close()
});