CREATE DATABASE if not exists finalproject;

use finalproject;

delete
from finalproject.accompany;

create table if not exists `accompany`
(
    CREATE TABLE accompany (
        ac_num INT AUTO_INCREMENT PRIMARY KEY,
        userId INT,
        FOREIGN KEY (userId) REFERENCES user(userId),
        ac_regdate DATE,
        ac_title VARCHAR(255),
        ac_text TEXT,
        ac_people INT,
        ac_region VARCHAR(255),
        ac_startdate DATE,
        ac_enddate DATE,
        ac_status VARCHAR(50),
        ac_picture VARCHAR(255),
        ac_viewcount INT,
        ac_travelstyle VARCHAR(50),
        ac_personalhash VARCHAR(255)
        );


create table if not exists `comment`
(
    co_num       INT AUTO_INCREMENT PRIMARY KEY,
    co_content   TEXT,
    co_writedate DATETIME,
    userId       INT,
    ac_num       INT,
    FOREIGN KEY (userId) REFERENCES user (userId),
    FOREIGN KEY (ac_num) REFERENCES accompany (ac_num)
);
