SELECT * FROM finalproject.accompany;

DROP TABLE accompany;
DROP TABLE comment;
DROP TABLE user;


CREATE DATABASE if not exists finalproject;

use finalproject;

delete from finalproject.user;


INSERT INTO `user` (`userId`,  `userName`, `userPassword`, `userPhone`, `userGender`, `userDate`, `userMbti`,`userImg`)
VALUES
    ('john_doe','John Doe', 'password123', '123-456-7890', 'M', '2023-08-21', 'ENTJ','default1.png'),
    ('jane_smith', 'Jane Smith', 'pass4321', '987-654-3210', 'F', '2023-08-21', 'INFP','default2.png'),
    ('alex_brown', 'Alex Brown', 'securepwd', '555-555-5555', 'M', '2023-08-21', 'INTJ','default1.png'),
    ('test', 'yeong', '1234', '555-555-5555', 'M', '2023-08-21', 'INTJ','default1.png'),
    ('sample@example.com', '샘플', '1234', '555-555-5555', 'M', '2023-08-21', 'INTJ','default1.png');


select * from user;


CREATE TABLE accompany (
    ac_num INT AUTO_INCREMENT PRIMARY KEY,
    userId INT,
    ac_regdate DATE,
    ac_title VARCHAR(255),
    ac_text TEXT,
    ac_people INT,
    ac_region VARCHAR(255),
    ac_startdate DATE,
    ac_enddate DATE,
    ac_status VARCHAR(50),
    ac_picture VARCHAR(255),
    ac_viewcount INT,
    ac_travelstyle VARCHAR(50),
    ac_personalhash VARCHAR(255)
);


-- article 더미데이터
INSERT INTO accompany (userId, ac_regdate, ac_title, ac_text, ac_people, ac_region, ac_startdate, ac_enddate,
                       ac_status, ac_picture, ac_viewcount, ac_travelstyle, ac_personalhash)
VALUES ('1', '2023-08-31', 'Sample Title', 'Sample Text', '2', 'Sample Region', '2023-09-01', '2023-09-10', 'Open',
        'sample.jpg', '100', 'Adventure', '#travel');
INSERT INTO accompany (userId, ac_regdate, ac_title, ac_text, ac_people, ac_region, ac_startdate, ac_enddate,
                       ac_status, ac_picture, ac_viewcount, ac_travelstyle, ac_personalhash)
VALUES ('2', '2023-08-31', 'Sample Title 2', 'Sample Text 2', '3', 'Sample Region 2', '2023-09-02', '2023-09-11', 'Open',
        'sample2.jpg', '150', 'Relaxation', '#vacation');
INSERT INTO accompany (userId, ac_regdate, ac_title, ac_text, ac_people, ac_region, ac_startdate, ac_enddate,
                       ac_status, ac_picture, ac_viewcount, ac_travelstyle, ac_personalhash)
VALUES ('3', '2023-08-31', 'Sample Title 6', 'Sample Text 6', '4', 'Sample Region 3', '2023-09-03', '2023-09-12', 'Open', 'sample6.jpg', '200', 'Exploration', '#adventure');


-- Comment 더미데이터
-- 5번 게시물의 댓글
INSERT INTO comment(co_number, userId, co_content, co_writedate, ac_num)
values (1, '한꼬마', '재벌집 막내아들', 2023-08-31, 1);
INSERT INTO comment(co_number, userId, co_content, co_writedate, ac_num)
values (2, '두꼬마', '빈센조', 2023-08-31, 1);
INSERT INTO comment(co_number, userId, co_content, co_writedate, ac_num)
values (3, '세꼬마', '태양의 후예', 2023-08-31, 1);

-- 6번 게시물의 댓글
INSERT INTO comment(co_number, userId, co_content, co_writedate, ac_num)
values (4, '한꼬마', '짜장면', 2023-08-31, 2);
INSERT INTO comment(co_number, userId, co_content, co_writedate, ac_num)
values (5, '두꼬마', '짬뽕', 2023-08-31, 2);
INSERT INTO comment(co_number, userId, co_content, co_writedate, ac_num)
values (6, '세꼬마', '탕수육', 2023-08-31, 2);

-- 7번 게시물의 댓글
INSERT INTO comment(co_num, userId, co_content, co_writedate, ac_num)
values (7, '한꼬마', '등산', 2023-08-31, 3);
INSERT INTO comment(co_num, userId, co_content, co_writedate, ac_num)
values (8, '두꼬마', '바둑', 2023-08-31, 3);
INSERT INTO comment(co_num, userId, co_content, co_writedate, ac_num)
values (9, '세꼬마', '낚시', 2023-08-31, 3);



SELECT * FROM accompany;

SELECT * FROM comment;

