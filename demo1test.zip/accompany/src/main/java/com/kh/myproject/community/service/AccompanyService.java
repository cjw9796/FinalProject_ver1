package com.kh.myproject.community.service;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccompanyService {


}